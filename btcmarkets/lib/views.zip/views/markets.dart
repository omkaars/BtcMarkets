import 'package:flutter/material.dart';

class MarketsView extends StatefulWidget {

  MarketsView();

  @override
  _MarketsViewState createState() => _MarketsViewState();

}

class _MarketsViewState extends State<MarketsView>
{

  @override
  Widget build(BuildContext context) {

    return new DefaultTabController(
      length: 3,
      child: Scaffold(

      )
    );
  }
}