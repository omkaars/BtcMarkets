import 'package:flutter/material.dart';
import 'home.dart';

import '../helpers/uihelpers.dart';

class BtcMarketsApp extends StatelessWidget
{
    BtcMarketsApp();

   static Color primaryColor = HexColor("#3C6B3C");
   static Color accentColor = HexColor("#ff9933");

   final darkTheme = ThemeData.dark().copyWith(
     primaryColor: primaryColor,
     accentColor: accentColor
   );
   final lightTheme = ThemeData.light().copyWith(
     primaryColor: primaryColor,
     accentColor: accentColor,
   );



    @override
   Widget build(BuildContext context) {
     return new MaterialApp(
       title: 'BTC Markets',
       theme: lightTheme,
        home: new HomeView(),
       routes: <String, WidgetBuilder>{

//            "/settings": (BuildContext context) => new SettingsView()

       },

       //onGenerateRoute: router.generator,
     );
   }

}