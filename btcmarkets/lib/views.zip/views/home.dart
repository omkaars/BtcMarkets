import 'package:flutter/material.dart';
import 'markets.dart';
import 'settings.dart';
import 'navdrawar.dart';

class TabView
{
    TabView(this.title, this.view);
    String title;
    PageView view;
}

class HomeView extends StatefulWidget {
  HomeView({Key key, this.title}) : super(key: key);

  final String title;

  @override
  _HomeViewState createState() => _HomeViewState();
}

class _HomeViewState extends State<HomeView> {
  int _selectedIndex = 0;
  String _title;
  NavDrawer _navDrawer =  new NavDrawer();



  _HomeViewState()
  {

    _title = widget.title??"Home";

  }
  List<TabView> _widgets = <TabView>[

    new TabView("Home", new PageView(
      children: <Widget>[
        Text("Home")
  ],
      )),
    new TabView("Markets", new PageView(
      children: <Widget>[
        MarketsView()
      ],
    )),
    new TabView("Trades", new PageView(
      children: <Widget>[
        Text("Trades")
      ],
    )),
    new TabView("Account", new PageView(
      children: <Widget>[
        Text("Account")
      ],
    )),
    new TabView("Settings", new PageView(
      children: <Widget>[
        SettingsView()
      ],
    )),
//    Text("Home"),
//    MarketsView(),
//    Text("Trades"),
//    Text("Account"),
//    Text("News"),
//    SettingsView()
  ];

  PageView _pageView;
  void _onItemTapped(int index) {
    setState(() {


      _selectedIndex = index;

    });
  }


  @override
  Widget build(BuildContext context) {

    return new Scaffold(
        drawer: _navDrawer,
        appBar:  new AppBar(
            title: Text( _widgets[_selectedIndex].title)
        ),
        body:_widgets[_selectedIndex].view,
      bottomNavigationBar: BottomNavigationBar(
        showUnselectedLabels: true,
        showSelectedLabels: true,
          type: BottomNavigationBarType.fixed,
          items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            title: Text('Home'),
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.show_chart),
            title: Text('Markets'),
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.swap_vert),
            title: Text('Trades'),
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.account_box),
            title: Text('Account'),
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.view_list),
            title: Text('News'),
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.more_horiz),
            title: Text('More'),
          ),
        ],
        currentIndex: _selectedIndex,
        selectedItemColor: Colors.amber[800],
        onTap: _onItemTapped,
      ),
    );
  }
}
