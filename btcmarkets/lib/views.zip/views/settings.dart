import 'package:flutter/material.dart';


class SettingsView extends StatefulWidget {


  SettingsView();

  @override
  _SettingsViewState createState() => _SettingsViewState();

}

class _SettingsViewState extends State<SettingsView>
{


  @override
  Widget build(BuildContext context) {

    return ListView(

          children: <Widget>[

            ListTile( title: Text("Api Keys")),
            Divider(height: 1),
            ListTile( title: Text("Theme")),
            ListTile( title: Text("Live Updates")),
            ListTile( title: Text("Notifications")),

          ],


        );

  }
}