import 'package:flutter/material.dart';
import 'navdrawar.dart';
import 'bottommenu.dart';
class MarketsView extends StatefulWidget {

  MarketsView();

  @override
  _MarketsViewState createState() => _MarketsViewState();

}

class _MarketsViewState extends State<MarketsView>
{

  NavDrawer _navDrawer =  new NavDrawer();
  BottomMenu _bottomMenu =  new BottomMenu(defaultIndex: 1);

  List<TabBarView> _widgets = <TabBarView>[

  ];

  @override
  Widget build(BuildContext context) {

    return new DefaultTabController(
      length: 3,
      child: SafeArea(
          child: Scaffold(
              drawer: _navDrawer,
              appBar: new AppBar(
                title: Text("Markets"),
                automaticallyImplyLeading: false,
                bottom: TabBar(
                      tabs: [

                        Tab(text: "Favourites",),
                        Tab(text: "AUD Markets"),
                        Tab(text: "BTC Markets"),
                      ],
                  ),
              ),
              body: Center(

              ),
              bottomNavigationBar: _bottomMenu,
          )
      )
    );
  }
}