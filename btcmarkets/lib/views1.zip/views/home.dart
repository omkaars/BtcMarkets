import 'package:flutter/material.dart';
import 'navdrawar.dart';
import 'bottommenu.dart';

class HomeView extends StatefulWidget {
  HomeView({Key key, this.title}) : super(key: key);

  final String title;

  @override
  _HomeViewState createState() => _HomeViewState();
}

class _HomeViewState extends State<HomeView> {

  NavDrawer _navDrawer =  new NavDrawer();
  BottomMenu _bottomMenu =  new BottomMenu(defaultIndex: 0);

  _HomeViewState();

  @override
  Widget build(BuildContext context) {



    return new SafeArea(child: Scaffold(
        drawer: _navDrawer,
        appBar: new AppBar(
            title: Text('Home')
        ),
        body: Center(

        ),
       bottomNavigationBar: _bottomMenu,
    )
    );
  }
}
