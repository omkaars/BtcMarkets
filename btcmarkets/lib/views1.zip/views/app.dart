import 'package:flutter/material.dart';
import 'home.dart';
import 'markets.dart';
import '../helpers/uihelpers.dart';

class BtcMarketsApp extends StatelessWidget
{
    BtcMarketsApp();

   static Color primaryColor = HexColor("#3C6B3C");
   static Color accentColor = HexColor("#ff9933");

   final darkTheme = ThemeData.dark().copyWith(
     primaryColor: primaryColor,
     accentColor: accentColor
   );
   final lightTheme = ThemeData.light().copyWith(
     primaryColor: primaryColor,
     accentColor: accentColor,
   );



    @override
   Widget build(BuildContext context) {
     return new MaterialApp(
       title: 'BTC Markets',
       theme: lightTheme,
        home: new HomeView(),
       routes: <String, WidgetBuilder>{
         "/markets": (BuildContext context) => new MarketsView(),
         },
     );
   }

}